import { useState } from 'react'
import './App.css'

function App() {
  const [header] = useState('ABCDEFGHIJKLMN'.split(''))

  return (
    <div className='container'>
      <div>TABLE</div>
      <table
        cellPadding={0}
        cellSpacing={0}
        style={{ width: '100%' }}
      >
        <tr className='control'>
          <td>Save</td>
          <td>Read file</td>
          <td>Sum</td>
          <td>Subtract</td>
          <td>Sort</td>
          <td>Average</td>
          <td>Max</td>
          <td>Min</td>
          <td>Add row</td>
          <td>Del row</td>
          <td>Add col</td>
          <td>del col</td>
        </tr>
        <tr>{
          header.map((item, i) => (
            <th
              key={i}
            >
              {item}
            </th>
          ))
        }</tr>
        {
          new Array(30).fill(0).map((item, i) => {
            return (
              <tr key={i}>
                <td>{i + 1}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            )
          })
        }
        
      </table>
    </div>
  )
}

export default App
