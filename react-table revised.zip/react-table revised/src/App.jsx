import { useState } from 'react'
import './App.css'

function App() {
  const [header] = useState('ABCDEFGHIJKLMN'.split(''))

  return (
    <div className='container'>
      <div>TABLE</div>
      <table
        cellPadding={0}
        cellSpacing={0}
        style={{ width: '100%' }}
      >
        <tr className='control'>
          <td><button type="submit">Save</button></td>
          <td><button type="submit">Read File</button></td>
          <td><button type="submit">Sum</button></td>
          <td><button type="submit">Subtract</button></td>
          <td><button type="submit">Sort</button></td>
          <td><button type="submit">Average</button></td>
          <td><button type="submit">Max</button></td>
          <td><button type="submit">Min</button></td>
          <td><button type="submit">Add row</button></td>
          <td><button type="submit">Del row</button></td>
          <td><button type="submit">Add col</button></td>
          <td><button type="submit">Del col</button></td>
        </tr>
        <tr>{
          header.map((item, i) => (
            <th
              key={i}
            >
              {item}
            </th>
          ))
        }</tr>
        {
          new Array(30).fill(0).map((item, i) => {
            return (
              <tr key={i}>
                <td>{i + 1}</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            )
          })
        }
        
      </table>
    </div>
  )
}

export default App
