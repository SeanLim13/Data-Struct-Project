import Function from "./components/Function";
import "./App.css";
import { useState } from "react";

function App() {
  const [TableHead, setTableHead] = useState<string[]>([]);
  const [TableBody, setTableBody] = useState<(string | number)[][]>([]);
  let MergeResult: (string | number)[][];
  let TempTableBody: (string | number)[][];

  const [inputVisible, setInputVisible] = useState(false);
  const [content, setContent] = useState<string>("");

  const handleWriteToFile = () => {
    let text = "";
    text += TableHead.length + "[,]";
    text += TableBody.length + "[,]";
    for (let i = 0; i < TableHead.length; i++) {
      text += TableHead[i] + "[,]";
    }
    for (let i = 0; i < TableBody.length; i++) {
      for (let j = 0; j < TableHead.length; j++) {
        text += TableBody[i][j] + "[,]";
      }
    }
    downloadFile("tableData.txt", text);
  };

  const updateNewTable = () => {
    const splitContent = content.split("[,]");
    const numberOfCols = parseInt(splitContent[0]);
    const numberOfRows = parseInt(splitContent[1]);
    let newTableHead: string[] = [];
    for (let i = 2; i < 2 + numberOfCols; i++) {
      newTableHead.push(splitContent[i]);
    }
    setTableHead(newTableHead);
    let newTableBody: (string | number)[][] = [];
    let rowIndex = -1,
      colIndex = 0;
    for (let i = 2 + numberOfCols; i < splitContent.length - 1; i++) {
      if (colIndex === 0) {
        newTableBody.push([]);
        rowIndex++;
      }
      newTableBody[rowIndex].push(splitContent[i]);
      colIndex++;
      colIndex %= numberOfCols;
    }
    setTableBody(newTableBody);
  };

  const handleReadFromFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const fileContent = e.target?.result as string;
      setContent(fileContent);
    };
    reader.readAsText(file);
    setInputVisible(false);
    updateNewTable();
  };

  const downloadFile = (filename: string, text: string) => {
    const element = document.createElement("a");
    const file = new Blob([text], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element); // Required for this to work in Firefox
    element.click();
  };

  const changeElement = (val: string, indexRow: number, indexCol: number) => {
    let newTable: (string | number)[][] = [];
    for (let i = 0; i < TableBody.length; i++) {
      newTable.push(TableBody[i]);
    }
    if ("" + parseFloat(val) !== val) newTable[indexRow][indexCol] = val;
    else newTable[indexRow][indexCol] = parseFloat(val);
    setTableBody(newTable);
  };

  const getIndexOfKey = (key: string) => {
    let index = -1;
    for (let i = 0; i < TableHead.length; i++) {
      if (TableHead[i] === key) index = i;
    }
    return index;
  };

  const saveFunction = () => {
    handleWriteToFile();
  };

  const openFileFunction = () => {
    setInputVisible(true);
  };

  const copyFunction = () => {
    let key = prompt("Which column do you want to copy?");
    let ind = getIndexOfKey(key!);
    addColFunction();
    let newTable: (string | number)[][] = [];
    for (let i = 0; i < TableBody.length; i++) newTable.push(TableBody[i]);
    for (let i = 0; i < TableBody.length; i++) {
      newTable[i][TableHead.length - 1] = newTable[i][ind];
    }
    setTableBody(newTable);
  };

  const sumFunction = () => {
    let key1 = prompt("Which column do you want to sum?");
    let key2 = prompt("Which column do you want to sum it with?");
    let ind1 = getIndexOfKey(key1!);
    let ind2 = getIndexOfKey(key2!);
    addColFunction();
    let newTable: (string | number)[][] = [];
    for (let i = 0; i < TableBody.length; i++) {
      newTable.push(TableBody[i]);
      if (
        typeof TableBody[i][ind1] === "string" ||
        typeof TableBody[i][ind2] === "string"
      )
        newTable[i].push((TableBody[i][ind1] as string) + TableBody[i][ind2]);
      else
        newTable[i].push(
          (TableBody[i][ind1] as number) + (TableBody[i][ind2] as number)
        );
    }
    setTableBody(newTable);
  };

  const subtractFunction = () => {
    let key1 = prompt("Which column do you want to subtract?");
    let key2 = prompt("Which column do you want to subtract it with?");
    let ind1 = getIndexOfKey(key1!);
    let ind2 = getIndexOfKey(key2!);
    addColFunction();
    let newTable: (string | number)[][] = [];
    for (let i = 0; i < TableBody.length; i++) {
      newTable.push(TableBody[i]);
      newTable[i].push(
        (TableBody[i][ind1] as number) - (TableBody[i][ind2] as number)
      );
    }
    setTableBody(newTable);
  };

  const mergeSort = (lf: number, rg: number, col: number) => {
    try {
      if (lf < rg) {
        let mid = Math.floor((lf + rg) / 2);
        mergeSort(lf, mid, col);
        mergeSort(mid + 1, rg, col);
        let ind = lf,
          ind1 = lf,
          ind2 = mid + 1;
        while (ind1 <= mid && ind2 <= rg) {
          if (MergeResult[ind1][col] < MergeResult[ind2][col])
            TempTableBody[ind++] = MergeResult[ind1++];
          else TempTableBody[ind++] = MergeResult[ind2++];
        }
        while (ind1 <= mid) TempTableBody[ind++] = MergeResult[ind1++];
        while (ind2 <= rg) TempTableBody[ind++] = MergeResult[ind2++];
        for (let i = lf; i <= rg; i++) MergeResult[i] = TempTableBody[i];
      }
    } catch (e) {
      alert(e);
    }
  };

  const sortFunction = () => {
    let key = prompt("Input column key:");
    TempTableBody = new Array(TableBody.length);
    MergeResult = new Array(TableBody.length);
    for (let i = 0; i < TableBody.length; i++) {
      MergeResult[i] = TableBody[i];
    }
    mergeSort(0, TableBody.length - 1, getIndexOfKey(key!));
    setTableBody(MergeResult);
  };

  const averageFunction = () => {
    try {
      let key = prompt("Input column key:");
      let index = getIndexOfKey(key!);
      let SumOfAll: number = 0;
      for (let i = 0; i < TableBody.length; i++) {
        if (typeof TableBody[i][index] === "string") throw "e";
        SumOfAll += TableBody[i][index] as number;
      }
      alert(
        "The average value for column " +
          key +
          " is " +
          SumOfAll / TableBody.length
      );
    } catch (e) {
      alert("Error occured");
    }
  };

  const maxFunction = () => {
    try {
      let key = prompt("Input column key:");
      let index = getIndexOfKey(key!);
      let largest = TableBody[0][index];
      for (let i = 1; i < TableBody.length; i++) {
        if (typeof TableBody[i][index] === "string") throw "e";
        if (TableBody[i][index] > largest) largest = TableBody[i][index];
      }
      alert("The max of " + key + " column is " + largest);
    } catch (e) {
      alert("Error occured");
    }
  };

  const minFunction = () => {
    try {
      let key = prompt("Input column key:");
      let index = getIndexOfKey(key!);
      let smallest = TableBody[0][index];
      for (let i = 1; i < TableBody.length; i++) {
        if (typeof TableBody[i][index] === "string") throw "e";
        if (TableBody[i][index] < smallest) smallest = TableBody[i][index];
      }
      alert("The min of " + key + " column is " + smallest);
    } catch (e) {
      alert("Error occured");
    }
  };

  const addRowFunction = () => {
    if (TableHead.length > 0) {
      let newRow: (string | number)[] = [];
      for (let i = 0; i < TableHead.length; i++) {
        newRow.push("");
      }
      let newTable: (string | number)[][] = [];
      for (let i = 0; i < TableBody.length; i++) {
        newTable.push(TableBody[i]);
      }
      newTable.push(newRow);
      setTableBody(newTable);
    }
  };

  const delRowFunction = () => {
    let ind = prompt("Which row do you want to delete?", "-1");
    let newTable: (string | number)[][] = [];
    for (let i = 0; i < TableBody.length; i++) {
      if (i !== parseInt(ind!) - 1) {
        newTable.push(TableBody[i]);
      }
    }
    setTableBody(newTable);
  };

  const addColFunction = () => {
    let key = prompt("Input the key of the new column");
    TableHead.push("" + key);
    let newTable: (string | number)[][] = [];

    TableBody.map((row, indexRow) => {
      newTable.push([]);
      row.map((col) => {
        newTable[indexRow].push(col);
      });
      newTable[indexRow].push("");
    });

    setTableBody(newTable);
  };

  const delColFunction = () => {
    let key = prompt("Enter the key of the column that you want to remove");
    let index = getIndexOfKey(key!);
    let newTableHead: string[] = [];
    let newTableBody: (string | number)[][] = [];
    for (let i = 0; i < TableHead.length; i++) {
      if (i !== index) {
        newTableHead.push(TableHead[i]);
      }
    }
    for (let i = 0; i < TableBody.length; i++) {
      let tempTable: (string | number)[] = [];
      for (let j = 0; j < TableHead.length; j++) {
        if (j !== index) {
          tempTable.push(TableBody[i][j]);
        }
      }
      newTableBody.push(tempTable);
    }
    setTableHead(newTableHead);
    setTableBody(newTableBody);
  };

  const functionName = [
    "Save",
    "Open file",
    "Copy",
    "Sum",
    "Subtract",
    "Sort",
    "Average",
    "Max",
    "Min",
    "Add row",
    "Delete row",
    "Add column",
    "Delete column",
  ];

  const functions = [
    saveFunction,
    openFileFunction,
    copyFunction,
    sumFunction,
    subtractFunction,
    sortFunction,
    averageFunction,
    maxFunction,
    minFunction,
    addRowFunction,
    delRowFunction,
    addColFunction,
    delColFunction,
  ];

  return (
    <>
      <script data-main="your-script.js" src="require.js"></script>
      <div className="set-height">
        <div className="row">
          {functions.map((func, index) => (
            <div className="col">
              <Function text={functionName[index]} onClick={func} />
            </div>
          ))}
        </div>
      </div>

      {inputVisible && <input type="file" onChange={handleReadFromFile} />}

      <table className="table table-striped">
        <thead>
          <tr>
            {TableHead.map((col) => (
              <th>{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {TableBody.map((row, indexRow) => (
            <tr>
              {row.map((col, indexCol) => (
                <td>
                  <input
                    value={TableBody[indexRow][indexCol]}
                    onChange={(e) =>
                      changeElement(e.target.value, indexRow, indexCol)
                    }
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default App;
