interface Props {
  text: string;
  onClick: () => void;
}

const Function = ({ text, onClick }: Props) => {
  return (
    <button className="btn btn-dark maxH" onClick={onClick}>
      {text}
    </button>
  );
};

export default Function;
